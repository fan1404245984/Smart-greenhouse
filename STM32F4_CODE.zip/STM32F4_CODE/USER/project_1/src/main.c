#include "main.h"
#include "led_key.h"
#include "exti.h"
#include "usart.h"
#include "string.h"
#include "delay.h"
#include "stdio.h"
#include "gy39.h"
#include "step_motor.h"
#include "pwm.h"
#include "blueteeth.h"
#include "adc.h"
#include "oled.h"
#include "codetab.h"

int main()
{
	delay_init(168); 
	led_init();
	beep_init();
	usart1_init(38400);	//串口1
	usart2_init(9600);	//串口2 蓝牙  通信
	gy39_init();		//串口3
	//STEP_MOTOR_Init();
	TIM_Init();			//定时器TIM3 灌溉,风扇电机控制
	TIM14_PWM();		//定时器14 补光灯
	adc1_init();		//初始化 模拟信号到数字信号的转换
	I2C_Configuration();//IIC 初始化
	OLED_Init();		//OLED屏 初始化


	OLED_CLS();
	delay_ms(1000);
	
	
	U_Data = get_adc();	//Camera工作电压值
	while(1)
	{
		pwm_ctrl_D1();	//补光灯
		blue_ctrl();	//蓝牙  控制
		gy39_ctrl();	//温湿度收集
		
			
		if(WD>30||SD<40)//温度超过30° 或者湿度低于40
		{
			unsigned char buff[64]={0};
			GPIO_ResetBits(GPIOE,GPIO_Pin_13);//1 蜂鸣器响，报警
			TIM_Cmd(TIM3, ENABLE);
			sprintf(buff,"GZ = %d Sun, WD = %d F, SD = %d cc ,QY = %d pp, HB = %d m",GZ,WD,SD,QY,HB);
			OLED_ShowStr(0,2,buff,1);
		}
		else
		{
			GPIO_SetBits(GPIOE,GPIO_Pin_13);//0
			if(cs_flag == CS_SYS)	//判断当前电机模式，蓝牙控制还是系统
			{
				TIM_Cmd(TIM3, DISABLE);
			}
		}

		
		//STEP_MOTOR_NUM (0,20,3);

		
	}
}
