#ifndef __GY39_H__
#define __GY39_H__
#include "stm32f4xx.h"
enum GY39MODE{GUANGZHAO,OTHER};
extern unsigned char gy39_mode;
extern unsigned char recvbuf39[32];
extern unsigned char data_len39;
extern unsigned char recv_ok39;
extern volatile unsigned int GZ,WD,QY,SD,HB;

void gy39_init(void);
void gy39_start(unsigned char mode);
void get_gy39_data(void);
void gy39_ctrl(void);

#endif
