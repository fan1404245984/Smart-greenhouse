#include "dac.h"
#define DAC_DHR12R1 0x40007408
void dac_output_tri(void)
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	DAC_InitTypeDef  DAC_InitStruct;
	/*初始化DAC通道对应的IO口*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;//禁用上下拉
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*初始化定时器来触发DAC*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
	TIM_TimeBaseInitStruct.TIM_Prescaler = 0;//不分频
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = 0xFF;
	TIM_TimeBaseInit(TIM6, &TIM_TimeBaseInitStruct);
	TIM_SelectOutputTrigger(TIM6, TIM_TRGOSource_Update);//更新事件触发TRGO信号
	TIM_Cmd(TIM6, ENABLE);

	/*初始化DAC*/
	RCC_APB1PeriphClockCmd( RCC_APB1Periph_DAC, ENABLE);
	DAC_InitStruct.DAC_OutputBuffer = DAC_OutputBuffer_Enable;//使能输出通道缓冲区
	DAC_InitStruct.DAC_Trigger = DAC_Trigger_T6_TRGO;//定时器6的TRGO信号触发
	DAC_InitStruct.DAC_LFSRUnmask_TriangleAmplitude = DAC_TriangleAmplitude_1023;
	DAC_InitStruct.DAC_WaveGeneration = DAC_WaveGeneration_Triangle;//生成三角波
	DAC_Init(DAC_Channel_1, &DAC_InitStruct);
	/*打开DAC*/
	DAC_Cmd(DAC_Channel_1, ENABLE);
	/*选择通道x的数据位和对齐方式，以及具体输出值*/
	DAC_SetChannel1Data(DAC_Align_12b_R, 0X100);
}

void DAC_DMA(const unsigned char * buf ,int len)
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	DAC_InitTypeDef  DAC_InitStruct;
	DMA_InitTypeDef  DMA_InitStruct;
	/*初始化DAC通道对应的IO口*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;//禁用上下拉
	GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*初始化定时器来触发DAC*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
	TIM_TimeBaseInitStruct.TIM_Prescaler = 0;//不分频
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = 0xFF;
	TIM_TimeBaseInitStruct.TIM_ClockDivision = 0;
	TIM_TimeBaseInit(TIM6, &TIM_TimeBaseInitStruct);
	TIM_SelectOutputTrigger(TIM6, TIM_TRGOSource_Update);//更新事件触发TRGO信号
	TIM_Cmd(TIM6, ENABLE);

	/*初始化DAC*/
	RCC_APB1PeriphClockCmd( RCC_APB1Periph_DAC, ENABLE);
	DAC_InitStruct.DAC_OutputBuffer = DAC_OutputBuffer_Enable;//使能输出通道缓冲区
	DAC_InitStruct.DAC_Trigger = DAC_Trigger_T6_TRGO;//定时器6的TRGO信号触发
	//DAC_InitStruct.DAC_LFSRUnmask_TriangleAmplitude = DAC_TriangleAmplitude_1023;
	DAC_InitStruct.DAC_WaveGeneration = DAC_WaveGeneration_None;//不产生波
	DAC_Init(DAC_Channel_1, &DAC_InitStruct);
	DAC_SetChannel1Data(DAC_Align_12b_R, 0X100);
	/*DMA配置*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);
	DMA_DeInit(DMA1_Stream5);
	DMA_InitStruct.DMA_Channel = DMA_Channel_7;
	DMA_InitStruct.DMA_PeripheralBaseAddr =(uint32_t)(&DAC->DHR12R1);//指定外设的基地址
	DMA_InitStruct.DMA_Memory0BaseAddr = (uint32_t)&buf;//指定内存的地址
	DMA_InitStruct.DMA_DIR = DMA_DIR_MemoryToPeripheral;//传输方向为内存到外设
	DMA_InitStruct.DMA_BufferSize = len;//指定缓冲去的大小
	DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//外设地址不递增
	DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;//内存地址递增
	DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//2个字节
	DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//2个字节
	DMA_InitStruct.DMA_Mode = DMA_Mode_Circular;//循环模式
	DMA_InitStruct.DMA_Priority = DMA_Priority_High;//高优先级
	DMA_InitStruct.DMA_FIFOMode = DMA_FIFOMode_Disable;//直接模式
	DMA_InitStruct.DMA_FIFOThreshold = DMA_FIFOStatus_HalfFull;
	DMA_InitStruct.DMA_MemoryBurst = DMA_MemoryBurst_Single;//单个节拍
	DMA_InitStruct.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//单个节拍
	DMA_Init(DMA1_Stream5, &DMA_InitStruct);

	/*打开DMA*/
	DMA_Cmd(DMA1_Stream5, ENABLE);
	/*打开DAC*/
	DAC_Cmd(DAC_Channel_1, ENABLE);
	/*启用或禁用指定的DAC通道DMA请求*/
	DAC_DMACmd(DAC_Channel_1, ENABLE);
}
