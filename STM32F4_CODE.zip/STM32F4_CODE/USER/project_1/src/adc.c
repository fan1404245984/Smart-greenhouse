#include "adc.h"

float U_Data=0; //最终的电压值
u32 ADC_EndFlag;
float Sintable[TableSize];


//Camera5 ==> PA4 ==> ADC1_IN4
void adc1_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	ADC_CommonInitTypeDef  ADC_CommonInitStruct;
	ADC_InitTypeDef  ADC_InitStruct;
	/*初始化ADC通道对应的IO口*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;//模拟功能
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;//禁止上下拉
	GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*ADC常用功能初始化配置*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	ADC_CommonInitStruct.ADC_Mode = ADC_Mode_Independent;//独立运行模式
	ADC_CommonInitStruct.ADC_Prescaler = ADC_Prescaler_Div4;
	ADC_CommonInitStruct.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;//禁用DMA
	ADC_CommonInitStruct.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;//5个时钟延时
	ADC_CommonInit(&ADC_CommonInitStruct);

	/*ADC初始化*/
	ADC_InitStruct.ADC_Resolution = ADC_Resolution_12b;//设置分辨率
	ADC_InitStruct.ADC_ScanConvMode = DISABLE;//禁用扫描模式
	ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;//禁用连续模式
	ADC_InitStruct.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;//禁止触发检测，使用软件触发
	ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;//数据右对齐
	ADC_InitStruct.ADC_NbrOfConversion = 1;//指定ADC转换的数目
	ADC_Init(ADC1, &ADC_InitStruct);

	/*
	ADC_ITConfig(ADC1,ADC_IT_EOC,ENABLE);
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel=ADC_IRQn;                   				//选择TIM3的定时器中断
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;      			//抢占优先级为2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=2;							//子优先级为2
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;					
	NVIC_Init(&NVIC_InitStructure);
	*/

	/*指定通道和使能ADC*/
	ADC_RegularChannelConfig(ADC1, ADC_Channel_4, 1, ADC_SampleTime_3Cycles);
	ADC_Cmd(ADC1,ENABLE);
}

void ADC_IRQHandler(void)
{
	static u32 n=0;
	if(ADC_GetITStatus(ADC1,ADC_FLAG_EOC)!=RESET)						          //等待转换结束		
	{		
		Sintable[n++]=ADC_GetConversionValue(ADC1)*3.3f/4096;			         //返回最近一次 ADC1 规则组的转换结果										//将读取到的数字量存入数组中
	}
										
	/*
	if(n==TableSize)
	{
		n=0;
		ADC_EndFlag=1;
		ADC_ITConfig(ADC1,ADC_IT_EOC,DISABLE);							//采集TableSize个数据后关闭ADC中断
	}
	*/
	ADC_ClearITPendingBit(ADC1,ADC_FLAG_EOC);							//清除中断标志位
}


float get_adc(void)
{
	ADC_SoftwareStartConv(ADC1);//软件触发开始转换
	while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC)==RESET);//等待转换完成
	//数字量乘单位数字量对应的模拟量就是我们真正的要读的模拟量
	U_Data = (float) (ADC_GetConversionValue(ADC1) *3.3 /4096);
	ADC_ClearFlag(ADC1, ADC_FLAG_EOC);
	return U_Data;

}

