#include "exti.h"
#include "led_key.h"
void exti_init(void)//PA0,PE2,PE3,PE4
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	EXTI_InitTypeDef  EXTI_InitStruct;
	NVIC_InitTypeDef  NVIC_InitStruct;
	/*中断源配置*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOE, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);//使能SYSCFG时钟
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOE, &GPIO_InitStruct);

	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA,EXTI_PinSource0);
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE,EXTI_PinSource2);
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE,EXTI_PinSource3);
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE,EXTI_PinSource4);

	/*EXTI 外部中断的配置*/
	EXTI_InitStruct.EXTI_Line = EXTI_Line0|EXTI_Line2|EXTI_Line3|EXTI_Line4;
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;//中断模式
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;//下降沿触发
	EXTI_Init(&EXTI_InitStruct);

	/*NVIC配置*/
	NVIC_InitStruct.NVIC_IRQChannel = EXTI0_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;//设置抢占优先级
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;//设置响应优先级
	NVIC_Init(&NVIC_InitStruct);
	NVIC_InitStruct.NVIC_IRQChannel = EXTI2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;//设置抢占优先级
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;//设置响应优先级
	NVIC_Init(&NVIC_InitStruct);
	NVIC_InitStruct.NVIC_IRQChannel = EXTI3_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;//设置抢占优先级
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;//设置响应优先级
	NVIC_Init(&NVIC_InitStruct);
	NVIC_InitStruct.NVIC_IRQChannel = EXTI4_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;//设置抢占优先级
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;//设置响应优先级
	NVIC_Init(&NVIC_InitStruct);

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//设置优先级分组
}



void EXTI0_IRQHandler(void)
{
	static int led_state = 0;//静态局部变量，初始化只执行一次，生存期随进程持续性。
	if(EXTI_GetFlagStatus(EXTI_Line0) == SET)
	{
		uint16_t tmpccr = TIM13->CCR1;
		TIM13->CCR1 = tmpccr-1000;
		led_ctrl(LED0 , led_state);
		led_state = !led_state;
		
		EXTI_ClearITPendingBit(EXTI_Line0);//清除标志位
	}
} 


void EXTI2_IRQHandler(void)
{
	static int led_state = 0;//静态局部变量，初始化只执行一次，生存期随进程持续性。
	if(EXTI_GetFlagStatus(EXTI_Line2) == SET)
	{
		uint16_t tmpccr = TIM13->CCR1;
		TIM13->CCR1 = tmpccr+1000;
		led_ctrl(LED1 , led_state);
		led_state = !led_state;

		EXTI_ClearITPendingBit(EXTI_Line2);//清除标志位
	}
}

void EXTI3_IRQHandler(void)
{
	static int led_state = 0;//静态局部变量，初始化只执行一次，生存期随进程持续性。
	if(EXTI_GetFlagStatus(EXTI_Line3) == SET)
	{
		led_ctrl(LED2 , led_state);
		led_state = !led_state;
		EXTI_ClearITPendingBit(EXTI_Line3);//清除标志位
	}
}

void EXTI4_IRQHandler(void)
{
	static int led_state = 0;//静态局部变量，初始化只执行一次，生存期随进程持续性。
	if(EXTI_GetFlagStatus(EXTI_Line4) == SET)
	{
		led_ctrl(LED3 , led_state);
		led_state = !led_state;
		EXTI_ClearITPendingBit(EXTI_Line4);//清除标志位
	}
}






