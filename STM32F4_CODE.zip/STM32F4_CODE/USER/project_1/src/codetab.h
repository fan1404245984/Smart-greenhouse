#ifndef _CODETAB_H_
#define _CODETAB_H_

extern unsigned char F16X16[];
extern const unsigned char F6x8[][6];
extern const unsigned char F8X16[];

#endif

