#ifndef __DAC_H__
#define __DAC_H__
#include "stm32f4xx.h"
void dac_output_tri(void);
void DAC_DMA(const unsigned char * buf ,int len);
void TIM6_Config(void);
void DAC_Ch1_NoiseConfig(void);
void DAC_Ch1_EscalatorConfig(void);
void DAC_Ch1_TriangleConfig(void);
void DAC_Ch2_SineWaveConfig(void);
void DAC_init(void);


#endif
