#ifndef __MQ2_H__
#define __MQ2_H__
#include "stm32f4xx.h"


extern unsigned char recvbuf[32];
extern unsigned char data_len;
extern unsigned char recv_ok;
extern volatile unsigned int value;

void MQ2_init(void);
void MQ2_start(void);
void get_MQ2_data(void);
#endif
