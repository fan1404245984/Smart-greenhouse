#include "MQ2.h"
#include "usart.h"
#include "string.h"
#include <stdio.h>

unsigned char MQ2_cmd1[]={0xFF,0x01,0x86,0x00,0x00,0x00,0x00,0x00,0x79};//
unsigned char recvbuf[32]={0};
unsigned char data_len=0;
unsigned char recv_ok=0;
volatile unsigned int value=0;


/*ע��: US_100��RX �� �������RX ,Tx �� �������Tx!*/
void MQ2_init(void)
{
	usart2_init(9600);
}


void MQ2_start(void)
{
	
	USART_SendDatas(USART2,MQ2_cmd1, 9);
	
}

void get_MQ2_data(void)
{
	
	value = recvbuf[2]<<8 | recvbuf[3];
	printf("the YanWu value is %d\r\n",value);
	recv_ok = 0;
	data_len = 0;
}
