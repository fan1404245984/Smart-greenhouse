#ifndef __USART_H__
#define __USART_H__
#include "stm32f4xx.h"
void usart1_init(uint32_t BaudRate);
void USART_SendDatas(USART_TypeDef * USARTx,uint8_t *buf, uint8_t len);
void usart2_init(uint32_t BaudRate);
void usart3_init(uint32_t BaudRate);//PB10-->Tx,PB11-->Rx


#endif
