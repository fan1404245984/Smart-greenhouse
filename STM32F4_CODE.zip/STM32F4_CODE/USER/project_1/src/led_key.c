#include "led_key.h"
#include "bitband.h"

void led_init(void)//PF9,PF10,PE13,PE14
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	/*使能GPIO分组的时钟*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF|RCC_AHB1Periph_GPIOE, ENABLE);
	/*GPIO口初始化*/
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;//开漏输出
	GPIO_InitStruct.GPIO_Speed = GPIO_Low_Speed;
	GPIO_Init( GPIOF, &GPIO_InitStruct);
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;//开漏输出
	GPIO_InitStruct.GPIO_Speed = GPIO_Low_Speed;
	GPIO_Init( GPIOE, &GPIO_InitStruct);
	/*操作GPIO口*/
	PFout(9) = 1;//GPIO_WriteBit(GPIOF, GPIO_Pin_9, (BitAction) 1);
	PFout(10) = 1;//GPIO_WriteBit(GPIOF, GPIO_Pin_10, (BitAction) 1);
	PEout(13) = 1;//GPIO_WriteBit(GPIOE, GPIO_Pin_13, (BitAction) 1);
	PEout(14) = 1;//GPIO_WriteBit(GPIOE, GPIO_Pin_14, (BitAction) 1);
}

void led_ctrl(int num, int led_state)
{
	switch(num)
	{
		case LED0:
			PFout(9) = led_state;//GPIO_WriteBit(GPIOF, GPIO_Pin_9, (BitAction) led_state);
			break;
		case LED1:
			PFout(10) = led_state;//GPIO_WriteBit(GPIOF, GPIO_Pin_10, (BitAction) led_state);
			break;
		case LED2:
			PEout(13) = led_state;//GPIO_WriteBit(GPIOE, GPIO_Pin_13, (BitAction) led_state);
			break;
		case LED3:
			PEout(14) = led_state;//GPIO_WriteBit(GPIOE, GPIO_Pin_14, (BitAction) led_state);
			break;
	}
}

void key_init(void)//PA0,PE2,PE3,PE4
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	/*使能GPIO分组的时钟*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOE, ENABLE);
	/*GPIO口初始化*/
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init( GPIOA, &GPIO_InitStruct);
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init( GPIOE, &GPIO_InitStruct);
}

int key_status(int num)
{
	switch(num)
	{
		case KEY0:
			return PAin(0);//GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0);
		case KEY1:
			return PEin(2);//GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2);
		case KEY2:
			return PEin(3);//GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3);
		case KEY3:
			return PEin(4);//GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4);
				
	}
	return -1;
}

void beep_init(void)
{

	GPIO_InitTypeDef GPIO_InitStruct;
	//1.使能GPIO分组的时钟  和F
	RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOF,ENABLE);
	//2.GPIO初始化 
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOF,&GPIO_InitStruct);
	//3.默认状态(蜂鸣器关)
	GPIO_ResetBits(GPIOF,GPIO_Pin_8);	
}
void Beep_Ctrl(void)//0关  1开
{
	GPIO_ToggleBits(GPIOF, GPIO_Pin_8);//翻转
}

