#ifndef __RTC_H__
#define __RTC_H__
#include "stm32f4xx.h"
int rtc_init(void);
void RTC_Alarm_init(void);
void RTC_WAKEUP_init(void);


#endif
