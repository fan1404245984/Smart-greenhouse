#ifndef __BLUETEETH_H__
#define __BLUETEETH_H__
#include "stm32f4xx.h"

#define CS_BLUE 1
#define CS_SYS 0

extern u8 blue_recv;
extern float U_Data;
extern u8 cs_flag;


void blue_ctrl(void);


#endif

