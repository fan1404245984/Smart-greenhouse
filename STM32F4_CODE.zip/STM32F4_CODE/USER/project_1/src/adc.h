#ifndef __ADC_H__
#define __ADC_H__
#include "stm32f4xx.h"

#define TableSize 200
extern float Sintable[TableSize];
extern float U_Data;

void adc1_init(void);
float get_adc(void);

#endif
