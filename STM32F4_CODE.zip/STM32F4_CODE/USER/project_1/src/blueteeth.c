#include "blueteeth.h"
#include "stdio.h"
#include "gy39.h"
#include "adc.h"
#include "oled.h"
#include "codetab.h"

u8 blue_recv = 0;
u8 cs_flag = 0;
unsigned char buff[64]={0};

void blue_ctrl(void)
{
	switch(blue_recv)
	{
		case 'p':
			OLED_CLS();
			sprintf(buff,"GZ = %d Sun, WD = %d F, SD = %d cc ,QY = %d pp, HB = %d m",GZ,WD,SD,QY,HB);
			OLED_ShowStr(0,2,buff,1);
			printf("U = %f V\n",U_Data);
			blue_recv=0;
			break;
		case 'r':
			cs_flag = CS_BLUE;
			TIM_Cmd(TIM3, ENABLE);
			break;
		case 's':
			cs_flag = CS_SYS;
			TIM_Cmd(TIM3, DISABLE);
			break;
		case 'l':
			TIM_Cmd(TIM14, ENABLE);
			blue_recv=0;
			break;
		case 'e':
			TIM_Cmd(TIM14, DISABLE);
			blue_recv=0;
			break;
		default:
			break;
	
	}
	

}
