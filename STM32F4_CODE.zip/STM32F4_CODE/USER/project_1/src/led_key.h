#ifndef __LED_KEY_H__
#define __LED_KEY_H__
#include "stm32f4xx.h"
enum LED_NUM{LED0,LED1,LED2,LED3};
enum LED_STATE{LED_ON,LED_OFF};
enum KEY_NUM{KEY0,KEY1,KEY2,KEY3};
enum KEY_STATUS{KEY_DOWN,KEY_UP};
void led_init(void);
void led_ctrl(int num, int led_state);
void key_init(void);
int key_status(int num);
void beep_init(void);
void Beep_Ctrl(void);//0关  1开


#endif


