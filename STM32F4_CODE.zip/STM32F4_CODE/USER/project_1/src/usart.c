#include "usart.h"
#include "led_key.h"
#include "stdio.h"
#include "gy39.h"
#include "blueteeth.h"

void usart1_init(uint32_t BaudRate)//PA9,PA10
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef  NVIC_InitStruct;
	/*GPIO口配置*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;//输入悬空
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);
	/*USART配置*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	USART_InitStruct.USART_BaudRate = BaudRate;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件流控
	USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;//收发模式，全双工
	USART_InitStruct.USART_Parity = USART_Parity_No;//无校验
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;//8bits数据位
	USART_Init(USART1,&USART_InitStruct);
	/* USART中断配置*/
	USART_ITConfig(USART1,USART_IT_RXNE, ENABLE);//设置来数据触发中断
	NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStruct);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	/*打开串口*/
	USART_Cmd(USART1, ENABLE);
}

void usart2_init(uint32_t BaudRate)//PA2,PA3
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef  NVIC_InitStruct;
	/*GPIO口配置*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;//输入悬空
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);
	/*USART配置*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	USART_InitStruct.USART_BaudRate = BaudRate;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件流控
	USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;//收发模式，全双工
	USART_InitStruct.USART_Parity = USART_Parity_No;//无校验
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;//8bits数据位
	USART_Init(USART2,&USART_InitStruct);
	/* USART中断配置*/
	USART_ITConfig(USART2,USART_IT_RXNE, ENABLE);//设置发送数据触发中断
	
	NVIC_InitStruct.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStruct);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	/*打开串口*/
	USART_Cmd(USART2, ENABLE);
}

void usart3_init(uint32_t BaudRate)//PB10-->Tx,PB11-->Rx
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef  NVIC_InitStruct;
	/*GPIO口配置*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;//输入悬空
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOB, &GPIO_InitStruct);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_USART3);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_USART3);
	/*USART配置*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	USART_InitStruct.USART_BaudRate = BaudRate;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件流控
	USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;//收发模式，全双工
	USART_InitStruct.USART_Parity = USART_Parity_No;//无校验
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;//8bits数据位
	USART_Init(USART3,&USART_InitStruct);
	/* USART中断配置*/
	USART_ITConfig(USART3,USART_IT_RXNE, ENABLE);//设置来数据触发中断
	NVIC_InitStruct.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStruct);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	/*打开串口*/
	USART_Cmd(USART3, ENABLE);
}




void USART1_IRQHandler(void)
{
	
	u8 data;
	if(USART_GetITStatus(USART1, USART_IT_RXNE) == SET)//由来数据引发中断
	{
		data = USART_ReceiveData(USART1);//读取接收到的数据
		if(data == 'A')
		{
			led_ctrl(LED0, LED_ON);
		}
		else if(data == 'B')
		{
			led_ctrl(LED0, LED_OFF);
		}
		
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);//清除标志位
	}
	
}

void USART2_IRQHandler(void)
{
	u8 recv;
	if(USART_GetITStatus(USART2, USART_IT_RXNE) == SET)//由来数据引发中断
	{
		recv =  USART_ReceiveData(USART2);
		blue_recv = recv;
		USART_SendData(USART2, recv);
	}
	
	USART_ClearITPendingBit(USART2, USART_IT_RXNE);//清除标志位
}

void USART3_IRQHandler(void)
{

	u8 data;
	if(USART_GetITStatus(USART3, USART_IT_RXNE) == SET)//由来数据引发中断
	{
		data = USART_ReceiveData(USART3);//读取接收到的数据
		recvbuf39[data_len39++] = data;
		if((data_len39==1 && recvbuf39[0]!=0x5A) || 
			(data_len39==2 && recvbuf39[0]!=0x5A && recvbuf39[1]!=0x5A))//帧头必须是0x5A,0x5A
		{
			data_len39 = 0;
		}
		
		if(gy39_mode == GUANGZHAO)
		{
			if(data_len39 == 9)
			{
				recv_ok39 = 1;
			}
		}
		else if(gy39_mode == OTHER)
		{
			if(data_len39 == 15)
			{
				recv_ok39 = 1;
			}
		}
		
		USART_ClearITPendingBit(USART3, USART_IT_RXNE);//清除标志位
	}
}


void USART_SendDatas(USART_TypeDef * USARTx,uint8_t *buf, uint8_t len)
{
	uint8_t i;
	for(i=0;i<len;i++)
	{
		USART_SendData(USARTx, buf[i]);
		while(USART_GetFlagStatus(USARTx,USART_FLAG_TXE) == RESET);//等待发送完成
	}
}




/*重定义fputc函数*/
struct __FILE
{
	int handle;
};

FILE __stdout;

int fputc(int ch, FILE *file)
{
	USART_SendData(USART2,ch);
	while(USART_GetFlagStatus(USART2,USART_FLAG_TXE) == RESET);//等待发送完成
	return ch;
}



