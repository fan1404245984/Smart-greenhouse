#include "rtc.h"
#include "delay.h"
#include "stdio.h"
int rtc_init(void)
{
	RTC_InitTypeDef  RTC_InitStruct;
	RTC_TimeTypeDef  RTC_TimeStruct;
	RTC_DateTypeDef  RTC_DateStruct;
	/*利用后备寄存器实现只对RTC初始化一次*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR,ENABLE);//使能电源控制器PWR时钟
	PWR_BackupAccessCmd(ENABLE);//使能后备寄存器访问

	if( RTC_ReadBackupRegister(RTC_BKP_DR0) != 0x55)
	{
		/*开启LSE时钟源，并作为RTC时钟*/
		u16 retry=0x1FFF;
		RCC_LSEConfig(RCC_LSE_ON);//LSE开启
		while(retry && RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)//等待LSE开启成功
		{
			retry++;
			delay_ms(10);
		}
		if(retry == 0)return -1;//LSE开启失败
		RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);//选择LSE做为RTC时钟源
		RCC_RTCCLKCmd(ENABLE);//使能RTC时钟
		/*初始化RTC*/
		RTC_InitStruct.RTC_AsynchPrediv = 0x7F;//RTC异步分频系数(1~0x7F)
		RTC_InitStruct.RTC_SynchPrediv = 0xFF;//RTC同步分频系数(0~7FFF)
        RTC_InitStruct.RTC_HourFormat = RTC_HourFormat_12;//12小时格式
		RTC_Init(&RTC_InitStruct);
		/*设置时间和日期*/
		RTC_TimeStruct.RTC_H12 = RTC_H12_AM;
		RTC_TimeStruct.RTC_Hours = 11;
		RTC_TimeStruct.RTC_Minutes = 24;
		RTC_TimeStruct.RTC_Seconds = 0;
		RTC_SetTime(RTC_Format_BIN, &RTC_TimeStruct);
		RTC_DateStruct.RTC_Date = 31;
		RTC_DateStruct.RTC_Month = 3;
		RTC_DateStruct.RTC_WeekDay = 3;
		RTC_DateStruct.RTC_Year = 21;
		RTC_SetDate(RTC_Format_BIN, &RTC_DateStruct);
		RTC_WriteBackupRegister ( RTC_BKP_DR0, 0x55); 
	}
	
	return 0;
}


void RTC_Alarm_init(void)
{
	RTC_AlarmTypeDef  RTC_AlarmStruct;
	RTC_TimeTypeDef  RTC_AlarmTime;
	EXTI_InitTypeDef EXTI_InitStruct;
	NVIC_InitTypeDef  NVIC_InitStruct;
	RTC_AlarmCmd(RTC_Alarm_A, DISABLE);//配置前先关掉闹钟
	/*RTC闹钟的日期时间设置*/
	RTC_AlarmTime.RTC_H12 = RTC_H12_PM;
	RTC_AlarmTime.RTC_Hours = 14;
	RTC_AlarmTime.RTC_Minutes = 35;
	RTC_AlarmTime.RTC_Seconds = 0;
	RTC_AlarmStruct.RTC_AlarmDateWeekDay = 3;//星期三
	RTC_AlarmStruct.RTC_AlarmDateWeekDaySel = RTC_AlarmDateWeekDaySel_WeekDay;//按周几闹
	RTC_AlarmStruct.RTC_AlarmMask = RTC_AlarmMask_Seconds;//屏蔽秒
	
	RTC_AlarmStruct.RTC_AlarmTime = RTC_AlarmTime;
	RTC_SetAlarm(RTC_Format_BIN, RTC_Alarm_A, &RTC_AlarmStruct);
	/*RTC闹钟中断配置*/
	RTC_ITConfig(RTC_IT_ALRA, ENABLE);//开启闹钟A中断
	RTC_AlarmCmd(RTC_Alarm_A, ENABLE);//开启闹钟A
	EXTI_InitStruct.EXTI_Line = EXTI_Line17;//LINE17
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;//中断模式
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising;//上升沿触发
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;//使能LINE17
	EXTI_Init(&EXTI_InitStruct);

	NVIC_InitStruct.NVIC_IRQChannel = RTC_Alarm_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStruct);
}

void RTC_Alarm_IRQHandler(void)
{
	if(RTC_GetFlagStatus(RTC_FLAG_ALRAF) == SET)//由闹钟A触发的中断
	{
		RTC_ClearFlag(RTC_FLAG_ALRAF);//清除标志位
		printf("RTC ALRAM A!\r\n");
	}
	EXTI_ClearITPendingBit(EXTI_Line17);//清除中断线的标志位
}

void RTC_WAKEUP_init(void)
{
	EXTI_InitTypeDef EXTI_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
	RTC_WakeUpCmd(DISABLE);
	/*RTC唤醒的时钟设置*/
	RTC_WakeUpClockConfig(RTC_WakeUpClock_CK_SPRE_16bits);
	/*设置RTC唤醒自动重载寄存器*/
	RTC_SetWakeUpCounter(60);
	/*RTC唤醒中断配置*/
	RTC_ClearITPendingBit(RTC_IT_WUT); //清除RTC WAKE UP的 标志位
	EXTI_ClearITPendingBit(EXTI_Line22);//清除LINE22上的中断标志位

	RTC_ITConfig(RTC_IT_WUT, ENABLE);//开启WAKE UP定时器中断
	RTC_WakeUpCmd(ENABLE);//开启WAKE UP定时器

	EXTI_InitStruct.EXTI_Line = EXTI_Line22;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;//中断模式
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising;//上升沿触发
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;//使能LINE22
	EXTI_Init(&EXTI_InitStruct);

	NVIC_InitStruct.NVIC_IRQChannel = RTC_WKUP_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init( &NVIC_InitStruct);//  RTC_WKUP_IRQn
}


void RTC_WKUP_IRQHandler(void)
{
	if(RTC_GetFlagStatus(RTC_FLAG_WUTF) == SET)//由WAKE UP引起的中断
	{
		RTC_ClearFlag(RTC_FLAG_WUTF);//清除中断标志
		printf("RTC WAKE UP!\r\n");
	}
	EXTI_ClearITPendingBit(EXTI_Line22);//清除中断线22的标志位

}

