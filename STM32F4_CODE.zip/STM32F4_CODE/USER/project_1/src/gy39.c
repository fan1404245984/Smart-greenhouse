#include "gy39.h"
#include "usart.h"
#include "string.h"
#include "stdio.h"
#include "led_key.h"
#include "delay.h"

unsigned char GY39_cmd1[]={0xA5,0x51,0xF6};//����ǿ��
unsigned char GY39_cmd2[]={0xA5,0x52,0xF7};//��������
unsigned char gy39_mode=0;
unsigned char recvbuf39[32]={0};
unsigned char data_len39=0;
unsigned char recv_ok39=0;
volatile unsigned int GZ,WD,QY,SD,HB=0;

void gy39_init(void)
{
	usart3_init(9600);
}


void gy39_start(unsigned char mode)
{
	gy39_mode = mode;
	if(gy39_mode == GUANGZHAO)
	{
		USART_SendDatas(USART3,GY39_cmd1, strlen((char*)GY39_cmd1));
	}
	else if(gy39_mode == OTHER)
	{
		USART_SendDatas(USART3,GY39_cmd2, strlen((char*)GY39_cmd2));
	}
}

void get_gy39_data(void)
{
	if(gy39_mode == GUANGZHAO)
	{
		GZ = recvbuf39[4]<<24 | recvbuf39[5]<<16 | recvbuf39[6]<<8 | recvbuf39[7];
		GZ = GZ/1000000;//光照
		//printf("GZ is %d\r\n",GZ);
	}
	else if(gy39_mode == OTHER)
	{
		WD = recvbuf39[4]<<8 | recvbuf39[5];//温度
		WD = WD/100;
		QY = recvbuf39[6]<<24 | recvbuf39[7]<<16 | recvbuf39[8]<<8 | recvbuf39[9];
		QY = QY/100000;//气压
		SD = recvbuf39[10]<<8 | recvbuf39[11];
		SD = SD/100;//湿度
		HB = recvbuf39[12]<<8 | recvbuf39[13];//海拔
		//printf("WD is %d,SD is %d,QY is %d,HB is %d\r\n",WD,SD,QY,HB);
	}
	recv_ok39 = 0;
	data_len39 = 0;
}

void gy39_ctrl(void)
{
	while(recv_ok39 == 0)
	{
		gy39_start(OTHER);
		delay_ms(200);
	}
	get_gy39_data();

	while(recv_ok39 == 0)
	{
		gy39_start(GUANGZHAO);
		delay_ms(200);
	}
	get_gy39_data();
}
