#include "pwm.h"
#include "led_key.h"
#include "stdio.h"

u16 d1_compare = 100;
u32 mode = 1;//1代表此时处于上升模式	0 代表此时处于下降模式

void TIM13_PWM(uint32_t Period,uint16_t Prescaler,uint32_t Pulse)//PF8
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseInitStruct;
	GPIO_InitTypeDef  GPIO_InitStruct;
	TIM_OCInitTypeDef TIM_OCInitStruct;
	/*使能定时器的时钟*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM13, ENABLE);
	/*GPIO配置*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;//复用功能模式
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOF, &GPIO_InitStruct);
	GPIO_PinAFConfig(GPIOF,GPIO_PinSource8,GPIO_AF_TIM13);//指定具体的复用功能
	/*定时器时基单元(Time Base Unit)的配置*/
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseInitStruct.TIM_Period = Period;
	TIM_TimeBaseInitStruct.TIM_Prescaler = Prescaler;
	TIM_TimeBaseInit(TIM13, &TIM_TimeBaseInitStruct);
    /*定时器输出通道配置*/
    TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStruct.TIM_Pulse = Pulse;//指定比较值 CCR
    TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;//指定高电平为有效电平
    TIM_OC1Init(TIM13, &TIM_OCInitStruct);
		
    TIM_OC1PreloadConfig( TIM13,TIM_OCPreload_Enable);//通道的比较值自动重装载使能
	
	/*定时器使能*/
	TIM_ARRPreloadConfig(TIM13, ENABLE);//定时器重装载使能
	TIM_Cmd(TIM13, ENABLE);
}

void TIM14_PWM()
{
	//使能RCC_APB1Periph_TIM14
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM14, ENABLE);	
	//使能F组寄存器的时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);

	//D1始化
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOF, &GPIO_InitStruct);
	
	//指定复用功能--> TIM14_CH1
	GPIO_PinAFConfig(GPIOF, GPIO_PinSource9, GPIO_AF_TIM14);

	
	//初始化时基单元
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_TimeBaseInitStruct.TIM_Prescaler = 83;		//设置预分频器	-->PSC	  -->Fcnt = 84Mhz/(83+1) = 1Mhz
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;	//设置定时器模式-->递增
	TIM_TimeBaseInitStruct.TIM_Period = 999;		//定时时间-->(1000*(1/10000hz))	  = 1ms
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;	//指定"输入捕获阶段"中数字滤波的采集频率的分频值
	TIM_TimeBaseInit(TIM14, &TIM_TimeBaseInitStruct);

	//配置输出通道(各个通道都是独立)	
	TIM_OCInitTypeDef TIM_OCInitStruct;
	TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;	 //TIMx_CNT < TIMx_CCR 输出有效电平 反之 输出无效电平
	TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStruct.TIM_Pulse = 0;
	TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OC1Init(TIM14,&TIM_OCInitStruct);
	
	//使能TIM14时钟
	TIM_Cmd(TIM14, ENABLE);
}



void pwm_ctrl_D1()
{
  	if(mode == 1)
  	{
  		d1_compare+=150;
  		if(d1_compare >= 900)
  		{
			d1_compare = 900;
  			mode = 0;
  		}
  	}
  	else
  	{
  		d1_compare-=150;
  		if(d1_compare <= 100)
  		{
			d1_compare = 100;
  			mode = 1;
  		}
  	}
	//printf("d1_compare = %d\n",d1_compare);
  	TIM_SetCompare1(TIM14,d1_compare);

}


void TIM_Init(void)		//TIM3
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3 , ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	//IN1,IN2,IN3,IN4脚 --- > GPIOC 6,7,8,9
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1 ; 
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;	//设置定时器模式-->递增
	TIM_TimeBaseInitStruct.TIM_Prescaler = 839;		//例：设置预分频器	-->PSC	  -->Fcnt = 84Mhz/(838+1) = 100000hz
	TIM_TimeBaseInitStruct.TIM_Period = 799;		//例：定时时间-->(2000*(1/100000hz))	  = 20ms
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStruct ) ; 

	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;    
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=2; 
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
	NVIC_Init(&NVIC_InitStructure);
	TIM_ITConfig(TIM3, TIM_IT_Update,ENABLE); 
	TIM_Cmd(TIM3, ENABLE); 
}

u8 TIM3_count= 0;
void TIM3_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
	{
		if(TIM3_count>3)
		{
			TIM3_count=0;
		}
		if(TIM3_count==0)
		{
			GPIO_SetBits(GPIOC, GPIO_Pin_6);
   			GPIO_SetBits(GPIOC, GPIO_Pin_7);
   			GPIO_ResetBits(GPIOC, GPIO_Pin_8);
   			GPIO_ResetBits(GPIOC, GPIO_Pin_9);
		}
		else if(TIM3_count==1)
		{
			GPIO_ResetBits(GPIOC, GPIO_Pin_6);
   			GPIO_SetBits(GPIOC, GPIO_Pin_7);
   			GPIO_SetBits(GPIOC, GPIO_Pin_8);
   			GPIO_ResetBits(GPIOC, GPIO_Pin_9);
		}
		else if(TIM3_count==2)
		{
			GPIO_ResetBits(GPIOC, GPIO_Pin_6);
   			GPIO_ResetBits(GPIOC, GPIO_Pin_7);
   			GPIO_SetBits(GPIOC, GPIO_Pin_8);
   			GPIO_SetBits(GPIOC, GPIO_Pin_9);
		}
		else if(TIM3_count==3)
		{
			GPIO_SetBits(GPIOC, GPIO_Pin_6);
   			GPIO_ResetBits(GPIOC, GPIO_Pin_7);
   			GPIO_ResetBits(GPIOC, GPIO_Pin_8);
   			GPIO_SetBits(GPIOC, GPIO_Pin_9);
		}
		TIM3_count++;
	}
	TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
}

