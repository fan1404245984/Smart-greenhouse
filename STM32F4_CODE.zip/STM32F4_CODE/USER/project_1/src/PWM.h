#ifndef __PWM_H__
#define __PWM_H__
#include "stm32f4xx.h"
void TIM13_PWM(uint32_t Period,uint16_t Prescaler,uint32_t Pulse);
void TIM14_PWM(void);
void pwm_ctrl_D1(void);

void TIM_Init(void);

#endif
